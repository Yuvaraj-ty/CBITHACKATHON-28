"""Payment processing gateway integration."""

class StripePaymentProcessor:
    """Handles credit card authorization, charges, and refunds."""

    def __init__(self, api_key: str):
        self.api_key = api_key

    def process_charge(self, customer_id: str, amount_cents: int) -> bool:
        """Charge the customer payment method for order total."""
        if amount_cents <= 0:
            raise ValueError("Amount must be greater than zero")
        print(f"Charged {customer_id} ${amount_cents / 100.0}")
        return True

    def refund_transaction(self, transaction_id: str, reason: str = "customer_request") -> bool:
        """Issue a full or partial refund back to customer."""
        print(f"Refunding transaction {transaction_id} because: {reason}")
        return True
