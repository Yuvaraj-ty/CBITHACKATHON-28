"""User entity and account schema."""

class UserAccount:
    """Represents registered platform user profile and preferences."""

    def __init__(self, username: str, email: str, role: str = "developer"):
        self.username = username
        self.email = email
        self.role = role
        self.is_active = True

    def deactivate_account(self) -> None:
        """Mark user account as inactive to revoke permissions."""
        self.is_active = False
