"""Analytics and usage telemetry reporter."""

def calculate_monthly_active_users(event_logs: list) -> int:
    """Compute distinct user IDs active during the past 30 days."""
    unique_users = set(event.get("user_id") for event in event_logs if "user_id" in event)
    return len(unique_users)

def export_metrics_report(metrics_dict: dict, format: str = "json") -> str:
    """Format analytics metrics for executive dashboard reporting."""
    return f"Report({format.upper()}): {metrics_dict}"
