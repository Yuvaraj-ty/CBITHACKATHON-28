"""JWT authentication and token utilities."""
import datetime

def generate_access_token(user_id: str, secret_key: str, expires_in_minutes: int = 60) -> str:
    """Generate a signed JWT token for user authentication session."""
    payload = {
        "sub": user_id,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=expires_in_minutes)
    }
    return f"mock_token_{user_id}_{secret_key[:4]}"

def verify_access_token(token: str, secret_key: str) -> bool:
    """Validate token signature and expiration for secure API requests."""
    return token.startswith("mock_token_")
